import React, { Component } from 'react';
import axios from 'axios'
import './fna.css';
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';
import { getCountry } from './dataService';
import { Select, MenuItem } from '@material-ui/core';


class FnA extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: getCountry(),
      selected: 'IN',
      columnDefs: [
        {
          "headerName": "",
          "children": [
            {
              "headerName": "ClientName",
              "field": "ClientName",
              "width": 150
            },
            {
              "headerName": "Total",
              "field": "Total",
              "width": 90
            }
          ]
        },
        {
          "headerName": "Municipal",
          "children": [
            {
              "headerName": "",
              "children": [
                {
                  "headerName": "TotalMunicipal",
                  "children": [
                    {
                      "headerName": "TotalMunicipal",
                      "field": "TotalMunicipal",
                      "width": 125
                    }
                  ]
                }
              ]
            },
            {
              "headerName": "IG",
              "columnGroupShow": "open",
              "children": [
                {
                  "headerName": "Total",
                  "children": [
                    {
                      "headerName": "Total",
                      "field": "Total_IG",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "YOY",
                  "children": [
                    {
                      "headerName": "YOY",
                      "field": "YOY_IG",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "F 2019 CV",
                  "children": [
                    {
                      "headerName": "F 2019 CV",
                      "field": "Y_CURR_IG",
                      "width": 90
                    }
                  ]
                }
              ]
            },
            {
              "headerName": "ABS",
              "columnGroupShow": "open",
              "children": [
                {
                  "headerName": "Total",
                  "children": [
                    {
                      "headerName": "Total",
                      "field": "Total_ABS",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "YOY",
                  "children": [
                    {
                      "headerName": "YOY",
                      "field": "YOY_ABS",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "F 2019 CV",
                  "children": [
                    {
                      "headerName": "F 2019 CV",
                      "field": "Y_CURR_ABS",
                      "width": 90
                    }
                  ]
                }
              ]
            },
            {
              "headerName": "Loans",
              "columnGroupShow": "open",
              "children": [
                {
                  "headerName": "Total",
                  "children": [
                    {
                      "headerName": "Total",
                      "field": "Total_Loans",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "YOY",
                  "children": [
                    {
                      "headerName": "YOY",
                      "field": "YOY_Loans",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "F 2019 CV",
                  "children": [
                    {
                      "headerName": "F 2019 CV",
                      "field": "Y_CURR_Loans",
                      "width": 90
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "headerName": "Credit",
          "children": [
            {
              "headerName": "",
              "children": [
                {
                  "headerName": "TotalCredit",
                  "children": [
                    {
                      "headerName": "TotalCredit",
                      "field": "TotalCredit",
                      "width": 90
                    }
                  ]
                }
              ]
            },
            {
              "headerName": "MoneyMarket",
              "columnGroupShow": "open",
              "children": [
                {
                  "headerName": "Total",
                  "children": [
                    {
                      "headerName": "Total",
                      "field": "Total_MoneyMarket",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "YOY",
                  "children": [
                    {
                      "headerName": "YOY",
                      "field": "YOY_MoneyMarket",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "F 2019 CV",
                  "children": [
                    {
                      "headerName": "F 2019 CV",
                      "field": "Y_CURR_MoneyMarket",
                      "width": 90
                    }
                  ]
                }
              ]
            },
            {
              "headerName": "CLO",
              "columnGroupShow": "open",
              "children": [
                {
                  "headerName": "Total",
                  "children": [
                    {
                      "headerName": "Total",
                      "field": "Total_CLO",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "YOY",
                  "children": [
                    {
                      "headerName": "YOY",
                      "field": "YOY_CLO",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "F 2019 CV",
                  "children": [
                    {
                      "headerName": "F 2019 CV",
                      "field": "Y_CURR_CLO",
                      "width": 90
                    }
                  ]
                }
              ]
            },
            {
              "headerName": "Converties",
              "columnGroupShow": "open",
              "children": [
                {
                  "headerName": "Total",
                  "children": [
                    {
                      "headerName": "Total",
                      "field": "Total_Converties",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "YOY",
                  "children": [
                    {
                      "headerName": "YOY",
                      "field": "YOY_Converties",
                      "width": 90
                    }
                  ]
                },
                {
                  "headerName": "F 2019 CV",
                  "children": [
                    {
                      "headerName": "F 2019 CV",
                      "field": "Y_CURR_Converties",
                      "width": 90
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "headerName": "",
          "children": [
            {
              "headerName": "Comments",
              "field": "Comments",
              "width": 150
            },
            {
              "headerName": "Coverage",
              "field": "Coverage",
              "width": 150
            }
          ]
        }
      ],
      defaultColDef: {
        sortable: true,
        resizable: true
      },
      rowData: null
    }
  }

  handleChange = event => {
    this.setState({ selected: event.target.value, name: event.target.name });
  };

  renderOptions() {
    return this.state.data.map((dt, i) => {
      //console.log(dt);
      return (
        <MenuItem
          label="Select a country"
          value={dt.country_code}
          key={i} name={dt.country_name}>{dt.country_name}</MenuItem>

      );
    });
  }

  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    const updateColumnData = data => {
      this.setState({ columnDefs: data });
    };

    const updateRowData = data => {
      this.setState({ rowData: data });
    };

    // https://api.myjson.com/bins/1d4gyz,  https://api.myjson.com/bins/e2dsb    -- Column Data
    // https://api.myjson.com/bins/ohc8r,   https://api.myjson.com/bins/163wdn     -- row data

    // axios.get('https://api.myjson.com/bins/1d4gyz')
    //   .then(res => {
    //     updateColumnData(res.data);
    //   })

    axios.get('https://api.myjson.com/bins/ohc8r')
      .then(res => {
        updateRowData(res.data);
      })

    // const httpRequest = new XMLHttpRequest();
    // httpRequest.open(
    //   "GET",
    //   "https://api.myjson.com/bins/163wdn"
    // );
    // httpRequest.send();
    // httpRequest.onreadystatechange = () => {
    //   if (httpRequest.readyState === 4 && httpRequest.status === 200) {
    //     updateRowData(httpRequest.responseText);
    //   }
    // };

    // this below code is giving error
    // params.api.addGlobalListener(function(type, event) {
    //   if (type.indexOf("column") >= 0) {
    //     console.log("Got column event: ", event);
    //   }
    // });
  };

  render() {
    return (
      <div className="App">
        {/* <h1> Welcome to FnA Portal </h1> */}
        { console.log(this.state.selected)}
        <Select className="width50" value={this.state.selected} onChange={this.handleChange}>
          {this.renderOptions()}
        </Select>
        <h3>Selected Country - {this.state.selected}</h3>
        <div
          className="ag-theme-balham"
          style={{
            height: '600px',
            width: '1200px'
          }}
        >
          <AgGridReact
            defaultColDef={this.state.defaultColDef}
            columnDefs={this.state.columnDefs}
            rowData={this.state.rowData}
            onGridReady={this.onGridReady}>
          </AgGridReact>
        </div>
      </div>
    );
  }
}

export default FnA;
