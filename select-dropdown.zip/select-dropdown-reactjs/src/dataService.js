export function getCountry() {
    return [
        { country_name: 'Afghanistan', country_code: 'AF' },
        { country_name: 'Åland Islands', country_code: 'AX' },
        { country_name: 'Albania', country_code: 'AL' },
        { country_name: 'Algeria', country_code: 'DZ' },
        { country_name: 'American Samoa', country_code: 'AS' },
        { country_name: 'AndorrA', country_code: 'AD' },
        { country_name: 'Angola', country_code: 'AO' },
        { country_name: 'Anguilla', country_code: 'AI' },
        { country_name: 'Antarctica', country_code: 'AQ' },
        { country_name: 'Antigua and Barbuda', country_code: 'AG' },
        { country_name: 'Argentina', country_code: 'AR' },
        { country_name: 'Armenia', country_code: 'AM' },
        { country_name: 'Aruba', country_code: 'AW' }, { country_name: 'Australia', country_code: 'AU' },
        { country_name: 'Austria', country_code: 'AT' },
        { country_name: 'Azerbaijan', country_code: 'AZ' },
        { country_name: 'Bahamas', country_code: 'BS' },
        { country_name: 'Bahrain', country_code: 'BH' },
        { country_name: 'Bangladesh', country_code: 'BD' },
        { country_name: 'Barbados', country_code: 'BB' },
        { country_name: 'Belarus', country_code: 'BY' },
        { country_name: 'India', country_code: 'IN' }
    ]
}
