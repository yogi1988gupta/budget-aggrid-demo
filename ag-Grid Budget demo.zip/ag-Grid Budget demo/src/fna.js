import React, { Component } from 'react';
import axios from 'axios'
import './fna.css';
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-balham.css';


class FnA extends Component {
  constructor(props) {
    super(props);
    this.state = {
      columnDefs: null,
      defaultColDef: {
        sortable: true,
        resizable: true
      },
      rowData: null
    }
  }

  onGridReady = params => {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;

    const updateColumnData = data => {
      this.setState({ columnDefs: data });
    };

    const updateRowData = data => {
      this.setState({ rowData: data });
    };

    // https://api.myjson.com/bins/1d4gyz,  https://api.myjson.com/bins/e2dsb    -- Column Data
    // https://api.myjson.com/bins/ohc8r,   https://api.myjson.com/bins/163wdn     -- row data

    axios.get('https://api.myjson.com/bins/1d4gyz')
      .then(res => {
        updateColumnData(res.data);
      })

    axios.get('https://api.myjson.com/bins/ohc8r')
      .then(res => {
        updateRowData(res.data);
      })

    // const httpRequest = new XMLHttpRequest();
    // httpRequest.open(
    //   "GET",
    //   "https://api.myjson.com/bins/163wdn"
    // );
    // httpRequest.send();
    // httpRequest.onreadystatechange = () => {
    //   if (httpRequest.readyState === 4 && httpRequest.status === 200) {
    //     updateRowData(httpRequest.responseText);
    //   }
    // };

    // this below code is giving error
    // params.api.addGlobalListener(function(type, event) {
    //   if (type.indexOf("column") >= 0) {
    //     console.log("Got column event: ", event);
    //   }
    // });
  };

  render() {
    return (
      <div className="App">
        {/* <h1> Welcome to FnA Portal </h1> */}
        <div
          className="ag-theme-balham"
          style={{
            height: '600px',
            width: '1200px'
          }}
        >
          <AgGridReact
            defaultColDef={this.state.defaultColDef}
            columnDefs={this.state.columnDefs}
            rowData={this.state.rowData}
            onGridReady={this.onGridReady}>
          </AgGridReact>
        </div>
      </div>
    );
  }
}

export default FnA;
